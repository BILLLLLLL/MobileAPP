import flask
from flask import Flask, request, render_template
from sklearn.externals import joblib
import numpy as np

app = Flask(__name__)

@app.route("/")
@app.route("/index")
def index():
    return flask.render_template('index.html')


@app.route('/predict', methods=['POST'])
def make_prediction():
	if request.method=='POST':

		entered_li = []


		# ---YOUR CODE FOR Part 2.2.3 ----  

		# Define "day", "open", "prn", "state", "school", and "store" variables
		df_combined = train_dataset.join(stores)
		df_combined = df_combined.reset_index(drop=True)
		df_combined.head()
		a = 1
		b = 2
		c = 3
		d = 4

		print(Store['a', 'b', 'c', 'd'])
		print(Assortment['a', 'b', 'c', 'd'])
		print(StateHoliday['a', 'b', 'c', 'd'])

		df_subset = df_combined[(df_combined['Store'] < 11)]
		sns.set(font_scale=2)

		fig, ax = plt.subplots(1,1)

		p3 = sns.barplot(x='Store', y='Sales', data=df_subset, ax=ax)
		ax.set(xlabel='Store Number')
		ax.set_ylabel('Average Sales')
		ax.set_title('Sales for ten stores')

		plt.show()

		avg_sales_per_store = df_combined[['Sales', 'Store']].groupby('Store').mean()
		avg_sales_per_store.reset_index().plot(kind='scatter', x='Store', y='Sales')
		plt.xlim(0,960)
		plt.title("Average Sales by Store Number")
		plt.show()
		g = sns.FacetGrid(df_combined, col="StoreType")
		g.map(plt.scatter, "Customers", "Sales")

		no_Promo_Date = df_combined.drop(['PromoInterval', 'Date'], axis=1)
		target = no_Promo_Date['Sales']

		# --- THE END OF CODE FOR Part 2.2.3 --- 

		# StoreType, Assortment, CompetitionDistance... arbitrary values
		for val in [1, 1, 290.0, 10.0, 2011.0, 1, 40.0, 2014.0, 0, 0, 0]:
			entered_li.append(val)


		# ---YOUR CODE FOR Part 2.2.4 ---- 
		
		# Predict from the model

		drop_sales_avg_df = no_Promo_Date.drop(['Sales', 'Customers'], axis=1)

		X_train, X_test, y_train, y_test = train_test_split(drop_sales_avg_df, target, test_size=0.33)


		regr = linear_model.LinearRegression()

		regr.fit(X_train, y_train)
	
		y_pred = regr.predict(X_test)

		print('R2 score: %.2f' % r2_score(y_test, y_pred))

		plt.figure(figsize=(20, 5))

		plt.plot(y_test.values, color='red', linewidth=0.1)
		plt.plot(y_pred, color='blue', linewidth=0.1)




		# --- THE END OF CODE FOR Part 2.2.4 --- 
		
		label = str(np.squeeze(prediction.round(2)))

		return render_template('index.html', label=label)

		print(regr)
  		return(str(regr[0]))


if __name__ == '__main__':

	# ---YOUR CODE FOR Part 2.2.1 ----  
	
	#Load ML model



	# --- THE END OF CODE FOR Part 2.2.1 --- 

	# start API
	app.run(host='0.0.0.0', port=8000, debug=True)

	pickle.dump(model, open(filename, 'wb'))
  	pickle.dump(cv, open("cv_model_vectorizer.pickle_prediction", "wb"))


